import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
// import "./styles.css";

ReactDOM.render(
  <App cat={5} txt="this is the prop text" />,
  document.getElementById("root")
);
// const rootElement = ;
